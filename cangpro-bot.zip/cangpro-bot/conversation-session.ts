/**
 * 對話 Session 管理器
 * 
 * 記錄每個 LINE 用戶的對話上下文，支援：
 * 1. 反問選項追蹤 — 用戶回覆數字時能對應到正確答案
 * 2. 對話歷史 — 讓 AI 生成回覆時有上下文
 * 3. 自動過期 — 避免記憶體無限增長
 */

// ========== 類型定義 ==========

/** 反問選項：數字 → 對應的搜索關鍵詞 */
export interface FollowUpOption {
  number: string;       // "1", "2", "3" 等
  label: string;        // 選項顯示文字，如「運費怎麼算（空快/海快）」
  searchQuery: string;  // 用來搜索 FAQ 的關鍵詞，如「運費怎麼算」
}

/** 對話記錄 */
export interface ConversationMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

/** 用戶 Session */
export interface UserSession {
  userId: string;
  /** 最後一次反問提供的選項 */
  pendingOptions: FollowUpOption[];
  /** 最後一次反問的意圖類別 */
  lastIntent: string | null;
  /** 對話歷史（最近 N 條） */
  history: ConversationMessage[];
  /** 最後活動時間 */
  lastActiveAt: number;
  /** Session 建立時間 */
  createdAt: number;
}

// ========== 配置 ==========

/** Session 過期時間：30 分鐘 */
const SESSION_TTL_MS = 30 * 60 * 1000;

/** 最大對話歷史條數 */
const MAX_HISTORY_LENGTH = 10;

/** 清理間隔：每 5 分鐘清理過期 session */
const CLEANUP_INTERVAL_MS = 5 * 60 * 1000;

/** 最大 session 數量（防止記憶體爆炸） */
const MAX_SESSIONS = 5000;

// ========== Session 存儲 ==========

const sessions = new Map<string, UserSession>();

// 定時清理過期 session
let cleanupTimer: ReturnType<typeof setInterval> | null = null;

function startCleanup() {
  if (cleanupTimer) return;
  cleanupTimer = setInterval(() => {
    const now = Date.now();
    let cleaned = 0;
    Array.from(sessions.entries()).forEach(([userId, session]) => {
      if (now - session.lastActiveAt > SESSION_TTL_MS) {
        sessions.delete(userId);
        cleaned++;
      }
    });
    if (cleaned > 0) {
      console.log(`[Session] 清理了 ${cleaned} 個過期 session，剩餘 ${sessions.size} 個`);
    }
  }, CLEANUP_INTERVAL_MS);
}

function ensureCapacity() {
  if (sessions.size < MAX_SESSIONS) return;
  // 按最後活動時間排序，刪除最舊的 20%
  const entries = Array.from(sessions.entries())
    .sort((a, b) => a[1].lastActiveAt - b[1].lastActiveAt);
  const toRemove = Math.floor(MAX_SESSIONS * 0.2);
  for (let i = 0; i < toRemove; i++) {
    sessions.delete(entries[i][0]);
  }
  console.log(`[Session] 容量清理：刪除了 ${toRemove} 個最舊 session`);
}

// ========== 公開 API ==========

/**
 * 取得或建立用戶 Session
 */
export function getSession(userId: string): UserSession {
  startCleanup();
  
  let session = sessions.get(userId);
  if (!session || Date.now() - session.lastActiveAt > SESSION_TTL_MS) {
    // 建立新 session 或過期重建
    ensureCapacity();
    session = {
      userId,
      pendingOptions: [],
      lastIntent: null,
      history: [],
      lastActiveAt: Date.now(),
      createdAt: Date.now(),
    };
    sessions.set(userId, session);
  }
  
  session.lastActiveAt = Date.now();
  return session;
}

/**
 * 記錄用戶訊息到對話歷史
 */
export function addUserMessage(userId: string, content: string): void {
  const session = getSession(userId);
  session.history.push({
    role: 'user',
    content,
    timestamp: Date.now(),
  });
  // 限制歷史長度
  if (session.history.length > MAX_HISTORY_LENGTH) {
    session.history = session.history.slice(-MAX_HISTORY_LENGTH);
  }
}

/**
 * 記錄 AI 回覆到對話歷史
 */
export function addAssistantMessage(userId: string, content: string): void {
  const session = getSession(userId);
  session.history.push({
    role: 'assistant',
    content,
    timestamp: Date.now(),
  });
  if (session.history.length > MAX_HISTORY_LENGTH) {
    session.history = session.history.slice(-MAX_HISTORY_LENGTH);
  }
}

/**
 * 設定反問選項（當 AI 發送帶數字選項的反問時調用）
 */
export function setPendingOptions(userId: string, options: FollowUpOption[], intent: string | null): void {
  const session = getSession(userId);
  session.pendingOptions = options;
  session.lastIntent = intent;
}

/**
 * 清除反問選項（當用戶選擇後或開始新話題時）
 */
export function clearPendingOptions(userId: string): void {
  const session = getSession(userId);
  session.pendingOptions = [];
  session.lastIntent = null;
}

/**
 * 檢查用戶輸入是否為數字選項回覆
 * 返回匹配的選項，或 null
 */
export function matchNumberOption(userId: string, userInput: string): FollowUpOption | null {
  const session = getSession(userId);
  if (session.pendingOptions.length === 0) return null;
  
  const trimmed = userInput.trim();
  
  // 匹配純數字：「1」「2」「3」
  if (/^[1-9]$/.test(trimmed)) {
    const option = session.pendingOptions.find(o => o.number === trimmed);
    if (option) return option;
  }
  
  // 匹配帶 emoji 的數字：「1️⃣」「2️⃣」
  const emojiMatch = trimmed.match(/^([1-9])\ufe0f?\u20e3$/);
  if (emojiMatch) {
    const num = emojiMatch[1];
    const option = session.pendingOptions.find(o => o.number === num);
    if (option) return option;
  }
  
  // 匹配中文數字：「一」「二」「三」
  const chineseNumMap: Record<string, string> = {
    '一': '1', '二': '2', '三': '3', '四': '4', '五': '5',
  };
  if (chineseNumMap[trimmed]) {
    const num = chineseNumMap[trimmed];
    const option = session.pendingOptions.find(o => o.number === num);
    if (option) return option;
  }
  
  return null;
}

/**
 * 取得對話歷史（用於 AI 生成回覆時的上下文）
 */
export function getConversationHistory(userId: string): ConversationMessage[] {
  const session = getSession(userId);
  return [...session.history];
}

/**
 * 取得 session 統計資訊（用於 debug）
 */
export function getSessionStats(): {
  activeSessions: number;
  totalMessages: number;
} {
  let totalMessages = 0;
  Array.from(sessions.values()).forEach(session => {
    totalMessages += session.history.length;
  });
  return {
    activeSessions: sessions.size,
    totalMessages,
  };
}

/**
 * 清除所有 session（用於測試）
 */
export function clearAllSessions(): void {
  sessions.clear();
}

/**
 * 停止清理定時器（用於測試清理）
 */
export function stopCleanup(): void {
  if (cleanupTimer) {
    clearInterval(cleanupTimer);
    cleanupTimer = null;
  }
}

// ========== 反問選項解析器 ==========

/**
 * 從反問模板文字中解析出數字選項
 * 例如：「1️⃣ 運費怎麼算（空快/海快）\n2️⃣ 台灣派送費」
 * → [{ number: "1", label: "運費怎麼算（空快/海快）", searchQuery: "運費怎麼算" }, ...]
 */
export function parseOptionsFromTemplate(templateText: string): FollowUpOption[] {
  const options: FollowUpOption[] = [];
  
  // 匹配 "1️⃣ xxx" 或 "1. xxx" 格式
  const lines = templateText.split('\n');
  for (const line of lines) {
    // 匹配 emoji 數字格式：1️⃣ 文字
    const emojiMatch = line.match(/([1-9])\ufe0f?\u20e3\s+(.+)/);
    if (emojiMatch) {
      const num = emojiMatch[1];
      const label = emojiMatch[2].trim();
      options.push({
        number: num,
        label,
        searchQuery: extractSearchQuery(label),
      });
      continue;
    }
    
    // 匹配普通數字格式：1. 文字 或 1、文字
    const numMatch = line.match(/^([1-9])[.、)]\s*(.+)/);
    if (numMatch) {
      const num = numMatch[1];
      const label = numMatch[2].trim();
      options.push({
        number: num,
        label,
        searchQuery: extractSearchQuery(label),
      });
    }
  }
  
  return options;
}

/**
 * 從選項標籤中提取搜索關鍵詞
 * 去除括號內容和多餘符號，保留核心詞
 */
function extractSearchQuery(label: string): string {
  return label
    .replace(/[（(][^）)]*[）)]/g, '') // 去除括號內容
    .replace(/[？?！!。，,]/g, '')      // 去除標點
    .trim();
}
