/**
 * 客戶轉接服務
 * 用於處理需要人工介入的客服問題
 */

import { invokeLLM } from "../_core/llm";
import { notifyOwner } from "../_core/notification";

export type EscalationReason = 
  | "product_error"      // 商品錯誤
  | "reconciliation"     // 對賬問題
  | "ai_unable"          // AI 無法處理
  | "other";             // 其他

export interface EscalationRequest {
  lineUserId: string;
  originalQuestion: string;
  aiResponse?: string;
  reason: EscalationReason;
  customerMessage?: string;
  metadata?: Record<string, any>;
}

/**
 * 判斷是否需要轉接人工
 * @param question 用戶問題
 * @param matchedFAQId 匹配的 FAQ ID
 * @param confidenceScore 匹配信心度（0-100）
 * @returns 是否需要轉接
 */
export function shouldEscalate(
  question: string,
  matchedFAQId: string | null,
  confidenceScore: number
): { shouldEscalate: boolean; reason?: EscalationReason } {
  // 檢測商品錯誤相關關鍵詞
  const productErrorKeywords = ["商品錯誤", "寄錯了", "發錯了", "拿錯", "不是我要的"];
  if (productErrorKeywords.some(keyword => question.includes(keyword))) {
    return { shouldEscalate: true, reason: "product_error" };
  }

  // 檢測對賬相關關鍵詞
  const reconciliationKeywords = ["對賬", "賬單", "費用不符", "多收", "少收", "金額"];
  if (reconciliationKeywords.some(keyword => question.includes(keyword))) {
    return { shouldEscalate: true, reason: "reconciliation" };
  }

  // 如果沒有匹配到 FAQ 或信心度太低，轉接人工
  if (!matchedFAQId || confidenceScore < 50) {
    return { shouldEscalate: true, reason: "ai_unable" };
  }

  return { shouldEscalate: false };
}

/**
 * 創建轉接請求
 * @param request 轉接請求信息
 * @returns 轉接 ID
 */
export async function createEscalation(
  request: EscalationRequest
): Promise<string> {
  const escalationId = `ESC_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  // 生成轉接摘要
  const summary = generateEscalationSummary(request);

  // 通知倉老闆所有者有新的轉接
  await notifyOwner({
    title: `🚨 新的客服轉接：${request.reason}`,
    content: summary,
  });

  // 記錄轉接信息到日誌
  console.log(`[Escalation] ${escalationId}:`, {
    lineUserId: request.lineUserId,
    reason: request.reason,
    question: request.originalQuestion,
    timestamp: new Date().toISOString(),
  });

  return escalationId;
}

/**
 * 生成轉接摘要
 */
function generateEscalationSummary(request: EscalationRequest): string {
  const reasonMap = {
    product_error: "商品錯誤",
    reconciliation: "對賬問題",
    ai_unable: "AI 無法處理",
    other: "其他問題",
  };

  return `
客戶 ID：${request.lineUserId}
轉接原因：${reasonMap[request.reason]}

客戶問題：
${request.originalQuestion}

AI 回覆：
${request.aiResponse || "（無回覆）"}

客戶補充：
${request.customerMessage || "（無補充）"}

請立即處理此轉接。
  `.trim();
}

/**
 * 生成轉接回覆消息
 * @param reason 轉接原因
 * @param escalationId 轉接 ID
 * @returns 回覆消息
 */
export function generateEscalationResponse(
  reason: EscalationReason,
  escalationId: string
): string {
  const responseMap = {
    product_error: `感謝您的反饋！我已經將您的商品錯誤問題轉接給我們的人工客服團隊。\n\n轉接編號：${escalationId}\n\n我們的客服會在 1 小時內聯繫您，幫您解決這個問題。請稍候。`,
    reconciliation: `感謝您的詢問！我已經將您的對賬問題轉接給我們的財務團隊。\n\n轉接編號：${escalationId}\n\n我們會詳細檢查您的賬單，並在 2 小時內回覆您。`,
    ai_unable: `這題太難了，我先記在小本本上，下次進化後再告訴你！已為您轉接人工管家，請稍等喔～\n\n轉接編號：${escalationId}\n\n我們的客服會在 30 分鐘內為您詳細解答。\n\n💡 您的問題對我們很重要，我們會學習並改進！`,
    other: `感謝您的反饋！我已經將您的問題轉接給我們的客服團隊。\n\n轉接編號：${escalationId}\n\n我們會盡快為您處理。`,
  };

  return responseMap[reason];
}

/**
 * 分析用戶消息，判斷是否需要轉接
 * @param userMessage 用戶消息
 * @param previousContext 之前的對話上下文
 * @returns 轉接決策
 */
export async function analyzeForEscalation(
  userMessage: string,
  previousContext?: string
): Promise<{
  needsEscalation: boolean;
  reason?: EscalationReason;
  confidence: number;
}> {
  // 快速檢查關鍵詞（只檢查明確的商品錯誤/對賬問題，不根據信心度快速轉接）
  const productErrorKeywords = ["商品錯誤", "寄錯了", "發錯了", "拿錯", "不是我要的"];
  if (productErrorKeywords.some(keyword => userMessage.includes(keyword))) {
    return {
      needsEscalation: true,
      reason: "product_error" as EscalationReason,
      confidence: 95,
    };
  }

  const reconciliationKeywords = ["對賬", "賬單", "費用不符", "多收", "少收"];
  if (reconciliationKeywords.some(keyword => userMessage.includes(keyword))) {
    return {
      needsEscalation: true,
      reason: "reconciliation" as EscalationReason,
      confidence: 95,
    };
  }

  // 如果快速檢查沒有發現問題，使用 AI 進行深度分析
  try {
    const analysisPrompt = `
分析以下客戶消息，判斷是否需要轉接給人工客服。

客戶消息：${userMessage}

${previousContext ? `之前的對話：${previousContext}` : ""}

重要規則：
- 只有以下情況才需要轉接人工客服：
  1. 商品錯誤（寄錯、發錯、破損）
  2. 對賬問題（費用不符、多收、少收）
  3. 客戶明確要求找人工客服
  4. 涉及具體訂單查詢（需要查系統）
- 以下情況不需要轉接，AI 可以回答：
  - 一般的服務詢問（運費、時效、流程、配送範圍等）
  - 簡單的問候或聊天
  - 運費計算相關問題
  - 關於服務範圍的問題（如配送地區）

請判斷：
1. 是否需要轉接？(是/否)
2. 如果需要，原因是什麼？(商品錯誤/對賬問題/AI無法處理/其他)
3. 信心度是多少？(0-100)

請用 JSON 格式回覆：
{
  "needsEscalation": boolean,
  "reason": "product_error|reconciliation|ai_unable|other",
  "confidence": number
}
    `.trim();

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "你是倉老闆的客服分析助手。分析客戶消息，判斷是否需要轉接給人工客服。大多數一般性問題（運費、時效、流程、配送地區、服務範圍等）AI 都可以回答，不需要轉接。只有商品錯誤、對賬問題、客戶明確要求人工、或需要查詢具體訂單時才需要轉接。",
        },
        {
          role: "user",
          content: analysisPrompt,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "escalation_analysis",
          strict: true,
          schema: {
            type: "object",
            properties: {
              needsEscalation: { type: "boolean" },
              reason: {
                type: "string",
                enum: ["product_error", "reconciliation", "ai_unable", "other"],
              },
              confidence: { type: "number", minimum: 0, maximum: 100 },
            },
            required: ["needsEscalation", "reason", "confidence"],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0].message.content;
    if (typeof content === "string") {
      const result = JSON.parse(content);
      return {
        needsEscalation: result.needsEscalation,
        reason: result.reason,
        confidence: result.confidence,
      };
    }
  } catch (error) {
    console.error("[Escalation Analysis Error]", error);
  }

  return {
    needsEscalation: false,
    confidence: 0,
  };
}
