import express from "express";
import Anthropic from "@anthropic-ai/sdk";
import {
  searchFAQWithScore,
  searchFAQ,
  generateFollowUpQuestion,
  generateMediumConfidenceReply,
  faqKnowledgeBase,
} from "./knowledge-base.js";
import {
  getSession,
  addUserMessage,
  addAssistantMessage,
  setPendingOptions,
  clearPendingOptions,
  matchNumberOption,
  getConversationHistory,
  parseOptionsFromTemplate,
  getSessionStats,
} from "./conversation-session.js";
import {
  extractWeight,
  extractWeightFromQuery,
  isShippingCalcTrigger,
  formatShippingQuoteMessage,
  generateWeightPrompt,
  hasRecentShippingContext,
  exceedsPackageLimit,
  generatePackageLimitWarning,
  extractDimensions,
  FALLBACK_RATE,
  AIR_EXPRESS_RATE,
  SEA_EXPRESS_RATE,
  SF_DELIVERY_RATES,
} from "./shipping-calculator.js";
import {
  isProductEstimateTrigger,
  estimateProductList,
  formatEstimationMessage,
} from "./product-estimator.js";

const app = express();
app.use(express.json());

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || "",
});

const LINE_CHANNEL_ACCESS_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN || "";

// ── 匯率取得（台銀API，失敗用備援） ──
async function getCNYRate(): Promise<number> {
  try {
    const res = await fetch(
      "https://api.exchangerate-api.com/v4/latest/CNY"
    );
    const data = await res.json() as any;
    return data?.rates?.TWD || FALLBACK_RATE;
  } catch {
    return FALLBACK_RATE;
  }
}

// ── 計算運費 ──
async function calculateShipping(weight: number) {
  const rate = await getCNYRate();
  const airRMB = Math.ceil(weight * AIR_EXPRESS_RATE * 10) / 10;
  const seaRMB = Math.ceil(weight * SEA_EXPRESS_RATE * 10) / 10;
  const airTWD = Math.round(airRMB * rate);
  const seaTWD = Math.round(seaRMB * rate);

  // 順豐費用
  let sfFee = SF_DELIVERY_RATES[SF_DELIVERY_RATES.length - 1].fee;
  for (const tier of SF_DELIVERY_RATES) {
    if (weight <= tier.maxKg) { sfFee = tier.fee; break; }
  }

  // 競品試算
  const rivalAirKg = Math.ceil(weight * 2) / 2;
  const rivalAirRMB = rivalAirKg <= 1 ? 29 : 29 + Math.ceil((rivalAirKg - 1) / 0.5) * 15.5;
  const rivalSeaKg = Math.max(weight, 10);
  const rivalSeaNTD = rivalSeaKg * 70;

  return {
    weight, rate,
    airRMB, airTWD, seaRMB, seaTWD, sfFee,
    rivalAirRMB, rivalSeaNTD
  };
}

function formatShippingMsg(q: Awaited<ReturnType<typeof calculateShipping>>): string {
  const ipostMin = 40; // 優惠價
  const ipostMax = 45;
  return `📦 運費試算結果（${q.weight}kg）

✈️ 極速空快（1-2天到台）
　頭程：${q.airRMB} RMB ≈ NT$${q.airTWD}
　+派送費：i郵箱NT$${ipostMin}起 / 順豐NT$${q.sfFee}

🚢 新航線海快（3-5天到台）
　頭程：${q.seaRMB} RMB ≈ NT$${q.seaTWD}
　+派送費：i郵箱NT$${ipostMin}起 / 順豐NT$${q.sfFee}

📊 同行比較
　同行空快：約${q.rivalAirRMB.toFixed(1)} RMB
　同行海快：約NT$${q.rivalSeaNTD}

💡 全程包稅，嚴格實重，不記拋
匯率：1 RMB ≈ NT$${q.rate.toFixed(3)}`;
}

// ── AI 生成回覆 ──
async function generateAIResponse(
  userMessage: string,
  history: { role: "user" | "assistant"; content: string }[]
): Promise<string> {
  const faqContext = faqKnowledgeBase
    .map((i) => `Q: ${i.question}\nA: ${i.answer}`)
    .join("\n\n");

  const systemPrompt = `你是倉老闆的AI客服助手，幫助台灣用戶解答集運問題。

知識庫：
${faqContext}

費率：
- 極速空快：21 RMB/kg（1-2天）
- 新航線海快：14 RMB/kg（3-5天）
- 台灣派送：i郵箱NT$40起（優惠至7/31）、順豐NT$95-245
- 全程包稅，嚴格實重計價

收件方式流程：
- 客人選i郵箱但沒給地址→引導查詢：打開 https://ezpost.post.gov.tw/ibox/e_map/index 選縣市找最近據點回傳地址
- 客人給宅配地址→找最近i郵箱→問箱到箱(NT$40起)還是箱到宅(NT$45起)
- 客人選順豐→問收件地址→記錄確認

規則：
1. 回覆簡潔，LINE限1000字
2. 友善親切，適時用emoji
3. 不確定就反問
4. 問題超出範圍請聯繫人工客服 @clb888`;

  const messages: Anthropic.MessageParam[] = [
    ...history.slice(-6).map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    })),
    { role: "user", content: userMessage },
  ];

  const res = await anthropic.messages.create({
    model: "claude-haiku-4-5-20251001",
    max_tokens: 800,
    system: systemPrompt,
    messages,
  });

  const block = res.content[0];
  return block.type === "text" ? block.text.slice(0, 1000) : "抱歉，請稍後再試或聯繫 @clb888";
}

// ── LINE 回覆 ──
async function replyMessage(replyToken: string, text: string) {
  await fetch("https://api.line.me/v2/bot/message/reply", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`,
    },
    body: JSON.stringify({
      replyToken,
      messages: [{ type: "text", text }],
    }),
  });
}

// ── LINE Push ──
export async function pushMessage(userId: string, text: string) {
  await fetch("https://api.line.me/v2/bot/message/push", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${LINE_CHANNEL_ACCESS_TOKEN}`,
    },
    body: JSON.stringify({
      to: userId,
      messages: [{ type: "text", text }],
    }),
  });
}

// ── 主要訊息處理 ──
async function handleTextMessage(event: any) {
  const userMessage = event.message?.text || "";
  const replyToken = event.replyToken;
  const lineUserId = event.source.userId;

  try {
    // 策略0：數字選項
    const matchedOption = matchNumberOption(lineUserId, userMessage);
    if (matchedOption) {
      const { results } = searchFAQWithScore(matchedOption.searchQuery, faqKnowledgeBase);
      if (results.length > 0) {
        clearPendingOptions(lineUserId);
        const reply = results[0].item.answer;
        addAssistantMessage(lineUserId, reply);
        await replyMessage(replyToken, reply);
        return;
      }
      clearPendingOptions(lineUserId);
    }

    // 策略0.3：商品估算
    if (isProductEstimateTrigger(userMessage)) {
      const estimation = await estimateProductList(userMessage);
      if (estimation && estimation.items.length > 0) {
        addUserMessage(lineUserId, userMessage);
        clearPendingOptions(lineUserId);
        const reply = formatEstimationMessage(estimation);
        addAssistantMessage(lineUserId, reply);
        await replyMessage(replyToken, reply);
        return;
      }
    }

    // 策略0.5：運費試算
    const trimmed = userMessage.trim();
    if (isShippingCalcTrigger(trimmed)) {
      const weight = extractWeightFromQuery(trimmed);
      if (weight) {
        const dims = extractDimensions(trimmed);
        if (exceedsPackageLimit(weight, dims.maxDimension, dims.totalDimensions)) {
          const warn = generatePackageLimitWarning(weight, dims.maxDimension, dims.totalDimensions);
          addUserMessage(lineUserId, userMessage);
          await replyMessage(replyToken, warn);
          return;
        }
        addUserMessage(lineUserId, userMessage);
        clearPendingOptions(lineUserId);
        const q = await calculateShipping(weight);
        const reply = formatShippingMsg(q);
        addAssistantMessage(lineUserId, reply);
        await replyMessage(replyToken, reply);
        return;
      } else {
        addUserMessage(lineUserId, userMessage);
        const reply = generateWeightPrompt();
        addAssistantMessage(lineUserId, reply);
        await replyMessage(replyToken, reply);
        return;
      }
    }

    // 純重量
    const directWeight = extractWeight(trimmed);
    if (directWeight) {
      const history = getConversationHistory(lineUserId);
      if (hasRecentShippingContext(history) || /\d+\.?\d*\s*(kg|公斤|斤)/i.test(trimmed)) {
        addUserMessage(lineUserId, userMessage);
        clearPendingOptions(lineUserId);
        const q = await calculateShipping(directWeight);
        const reply = formatShippingMsg(q);
        addAssistantMessage(lineUserId, reply);
        await replyMessage(replyToken, reply);
        return;
      }
    }

    addUserMessage(lineUserId, userMessage);

    // FAQ搜索
    const { results, intents } = searchFAQWithScore(userMessage, faqKnowledgeBase);

    if (results.length > 0 && results[0].confidence === "high") {
      clearPendingOptions(lineUserId);
      const reply = results[0].item.answer;
      addAssistantMessage(lineUserId, reply);
      await replyMessage(replyToken, reply);
      return;
    }

    if (results.length > 0 && results[0].confidence === "medium") {
      const reply = generateMediumConfidenceReply(results[0].item.answer, results[0].item.question);
      clearPendingOptions(lineUserId);
      addAssistantMessage(lineUserId, reply.slice(0, 1000));
      await replyMessage(replyToken, reply.slice(0, 1000));
      return;
    }

    if (intents.length > 0) {
      const followUp = generateFollowUpQuestion(intents);
      const options = parseOptionsFromTemplate(followUp);
      if (options.length > 0) setPendingOptions(lineUserId, options, intents[0]);
      addAssistantMessage(lineUserId, followUp);
      await replyMessage(replyToken, followUp);
      return;
    }

    // AI 生成
    const history = getConversationHistory(lineUserId);
    const aiResponse = await generateAIResponse(userMessage, history);
    addAssistantMessage(lineUserId, aiResponse);
    await replyMessage(replyToken, aiResponse);

  } catch (error) {
    console.error("Error:", error);
    const errMsg = "抱歉，我暫時無法處理您的問題，請聯繫人工客服 @clb888";
    await replyMessage(replyToken, errMsg);
  }
}

// ── Webhook 路由 ──
app.post("/api/line/webhook", async (req, res) => {
  res.sendStatus(200);
  const { events } = req.body;
  for (const event of events || []) {
    if (event.type === "message" && event.message?.type === "text") {
      await handleTextMessage(event);
    }
  }
});

app.get("/healthz", (_, res) => res.json({ status: "ok" }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`CangPro Bot running on port ${PORT}`));
