/**
 * 商品智能估算器
 * 
 * 從用戶的自然語言輸入中解析商品清單（品類+數量），
 * 自動估算總重量，並計算運費（含同行對比、雙幣顯示）。
 * 
 * 使用場景：
 * - 「我買了3件T恤和一雙鞋」
 * - 「幫我估 2件衛衣 + 1個背包」
 * - 「想寄5件衣服和2盒面膜」
 */

import { calculateShippingWithRate, type ShippingQuote } from "./shipping-calculator";

// ========== 商品重量資料庫 ==========

export interface ProductWeight {
  /** 品類名稱（用於顯示） */
  name: string;
  /** 匹配關鍵詞（用於解析） */
  keywords: string[];
  /** 最小重量（kg） */
  minKg: number;
  /** 最大重量（kg） */
  maxKg: number;
  /** 預設估算重量（取中間偏上值，含包裝） */
  defaultKg: number;
  /** 量詞（件/雙/個/組/盒） */
  unit: string;
  /** 特殊提醒（如特貨） */
  note?: string;
}

/**
 * 商品重量資料庫
 * 預設重量取中間偏上值（含包裝約 +0.1kg），確保估算不會偏低
 */
export const PRODUCT_WEIGHT_DB: ProductWeight[] = [
  // ── 衣服類 ──
  { name: "T恤/上衣", keywords: ["t恤", "上衣", "短袖", "polo", "polo衫"], minKg: 0.2, maxKg: 0.4, defaultKg: 0.35, unit: "件" },
  { name: "襯衫", keywords: ["襯衫", "襯衣"], minKg: 0.2, maxKg: 0.4, defaultKg: 0.35, unit: "件" },
  { name: "帽T/衛衣", keywords: ["帽t", "衛衣", "連帽", "hoodie", "帽衫"], minKg: 0.5, maxKg: 1, defaultKg: 0.8, unit: "件" },
  { name: "牛仔褲", keywords: ["牛仔褲", "牛仔", "丹寧"], minKg: 0.5, maxKg: 0.9, defaultKg: 0.7, unit: "件" },
  { name: "褲子", keywords: ["褲子", "短褲", "休閒褲", "長褲", "運動褲", "棉褲", "西褲"], minKg: 0.3, maxKg: 0.6, defaultKg: 0.5, unit: "件" },
  { name: "洋裝/裙子", keywords: ["洋裝", "連身裙", "裙子", "裙", "長裙", "短裙"], minKg: 0.3, maxKg: 1, defaultKg: 0.6, unit: "件" },
  { name: "外套/夾克", keywords: ["外套", "夾克", "風衣", "棒球外套", "飛行外套", "jacket"], minKg: 0.5, maxKg: 1.2, defaultKg: 0.9, unit: "件" },
  { name: "羽絨外套/大衣", keywords: ["羽絨", "大衣", "羽絨衣", "羽絨外套", "棉衣", "棉襖"], minKg: 0.85, maxKg: 2.5, defaultKg: 1.5, unit: "件" },
  { name: "運動套裝", keywords: ["運動套裝", "套裝", "運動服"], minKg: 0.7, maxKg: 1.5, defaultKg: 1.0, unit: "套" },
  { name: "睡衣", keywords: ["睡衣", "家居服", "居家服"], minKg: 0.3, maxKg: 0.6, defaultKg: 0.45, unit: "套" },
  { name: "內衣/內褲", keywords: ["內衣", "內褲", "胸罩", "bra", "四角褲"], minKg: 0.05, maxKg: 0.2, defaultKg: 0.15, unit: "件" },
  // 通用「衣服」— 當用戶只說「衣服」不指定類型時
  { name: "衣服（通用）", keywords: ["衣服", "衣物", "服飾", "衫"], minKg: 0.2, maxKg: 1, defaultKg: 0.5, unit: "件" },

  // ── 鞋子類 ──
  { name: "運動鞋/球鞋", keywords: ["運動鞋", "球鞋", "跑鞋", "籃球鞋", "慢跑鞋", "nike", "adidas"], minKg: 0.6, maxKg: 1, defaultKg: 0.85, unit: "雙" },
  { name: "涼鞋/拖鞋", keywords: ["涼鞋", "拖鞋", "人字拖", "夾腳拖"], minKg: 0.4, maxKg: 0.9, defaultKg: 0.6, unit: "雙" },
  { name: "靴子", keywords: ["靴子", "馬丁靴", "雪靴", "長靴", "短靴"], minKg: 0.8, maxKg: 1.5, defaultKg: 1.2, unit: "雙" },
  { name: "皮鞋", keywords: ["皮鞋", "樂福鞋", "牛津鞋", "帆船鞋"], minKg: 0.5, maxKg: 1, defaultKg: 0.8, unit: "雙" },
  // 通用「鞋子」
  { name: "鞋子（通用）", keywords: ["鞋子", "鞋", "買鞋"], minKg: 0.6, maxKg: 1, defaultKg: 0.85, unit: "雙" },

  // ── 包包配件 ──
  { name: "錢包", keywords: ["錢包", "皮夾", "長夾", "短夾"], minKg: 0.3, maxKg: 0.6, defaultKg: 0.4, unit: "個" },
  { name: "手提包/側背包", keywords: ["手提包", "側背包", "斜背包", "肩背包", "包包", "背包", "書包", "後背包"], minKg: 0.6, maxKg: 1.1, defaultKg: 0.9, unit: "個" },
  { name: "旅行袋", keywords: ["旅行袋", "行李袋", "旅行包", "大包"], minKg: 0.5, maxKg: 4, defaultKg: 2.0, unit: "個" },
  { name: "帽子", keywords: ["帽子", "棒球帽", "漁夫帽", "鴨舌帽", "遮陽帽"], minKg: 0.2, maxKg: 0.4, defaultKg: 0.3, unit: "頂" },
  { name: "圍巾", keywords: ["圍巾", "絲巾", "披肩"], minKg: 0.2, maxKg: 0.6, defaultKg: 0.4, unit: "條" },
  { name: "皮帶", keywords: ["皮帶", "腰帶", "belt"], minKg: 0.2, maxKg: 0.5, defaultKg: 0.35, unit: "條" },

  // ── 3C 電子 ──
  { name: "手機殼", keywords: ["手機殼", "手機套", "保護殼", "保護套"], minKg: 0.05, maxKg: 0.15, defaultKg: 0.1, unit: "個" },
  { name: "充電線/配件", keywords: ["充電線", "充電器", "傳輸線", "數據線", "type-c", "lightning"], minKg: 0.1, maxKg: 0.3, defaultKg: 0.2, unit: "條" },
  { name: "耳機", keywords: ["耳機", "藍牙耳機", "無線耳機", "有線耳機", "airpods"], minKg: 0.2, maxKg: 0.5, defaultKg: 0.35, unit: "副", note: "藍牙耳機含電池屬特貨，可寄但請先確認" },
  { name: "行動電源", keywords: ["行動電源", "充電寶", "移動電源"], minKg: 0.3, maxKg: 0.5, defaultKg: 0.4, unit: "個", note: "⚠️ 含電池屬特貨，請先加 LINE @clb888 確認" },
  { name: "鍵盤", keywords: ["鍵盤", "機械鍵盤", "無線鍵盤"], minKg: 0.5, maxKg: 1.2, defaultKg: 0.8, unit: "把" },
  { name: "滑鼠", keywords: ["滑鼠", "鼠標", "無線滑鼠"], minKg: 0.1, maxKg: 0.3, defaultKg: 0.2, unit: "個" },

  // ── 居家用品 ──
  { name: "毛巾/浴巾", keywords: ["毛巾", "浴巾", "面巾"], minKg: 0.3, maxKg: 0.8, defaultKg: 0.5, unit: "條" },
  { name: "床單/被套", keywords: ["床單", "被套", "床包", "被單", "枕套", "床組", "四件套", "三件套"], minKg: 1, maxKg: 3, defaultKg: 2.0, unit: "組" },
  { name: "枕頭", keywords: ["枕頭", "抱枕", "靠枕", "靠墊"], minKg: 0.5, maxKg: 1.5, defaultKg: 1.0, unit: "個" },
  { name: "收納盒", keywords: ["收納盒", "收納箱", "整理箱", "收納"], minKg: 0.3, maxKg: 1, defaultKg: 0.6, unit: "個" },
  { name: "杯子/水壺", keywords: ["杯子", "水壺", "保溫杯", "馬克杯", "隨行杯"], minKg: 0.3, maxKg: 0.8, defaultKg: 0.5, unit: "個" },

  // ── 美妝保養 ──
  { name: "面膜", keywords: ["面膜"], minKg: 0.2, maxKg: 0.3, defaultKg: 0.25, unit: "盒", note: "以10片/盒計算" },
  { name: "化妝品套組", keywords: ["化妝品", "彩妝", "化妝品套組", "美妝套組"], minKg: 0.3, maxKg: 1, defaultKg: 0.6, unit: "組" },
  { name: "護膚品", keywords: ["護膚品", "乳液", "精華液", "化妝水", "面霜", "防曬", "保養品"], minKg: 0.2, maxKg: 0.5, defaultKg: 0.35, unit: "瓶", note: "⚠️ 液體類屬特貨，請先加 LINE @clb888 確認" },
  { name: "口紅/粉底", keywords: ["口紅", "粉底", "眼影", "腮紅", "蜜粉", "唇膏"], minKg: 0.05, maxKg: 0.2, defaultKg: 0.12, unit: "個" },
  { name: "香水", keywords: ["香水", "香氛"], minKg: 0.2, maxKg: 0.5, defaultKg: 0.35, unit: "瓶", note: "⚠️ 液體類屬特貨，請先加 LINE @clb888 確認" },

  // ── 玩具/文具 ──
  { name: "公仔/模型", keywords: ["公仔", "模型", "手辦", "figure", "扭蛋"], minKg: 0.2, maxKg: 1, defaultKg: 0.5, unit: "個" },
  { name: "文具套組", keywords: ["文具", "文具套組", "筆", "鉛筆盒", "筆袋"], minKg: 0.3, maxKg: 0.8, defaultKg: 0.5, unit: "組" },
  { name: "拼圖/桌遊", keywords: ["拼圖", "桌遊", "board game", "積木"], minKg: 0.5, maxKg: 2, defaultKg: 1.2, unit: "盒" },
  { name: "樂高", keywords: ["樂高", "lego"], minKg: 0.5, maxKg: 3, defaultKg: 1.5, unit: "盒" },
  { name: "絨毛玩偶", keywords: ["絨毛", "玩偶", "娃娃", "布偶", "毛絨"], minKg: 0.3, maxKg: 1.5, defaultKg: 0.8, unit: "個" },
  { name: "童裝", keywords: ["童裝", "兒童衣服", "小孩衣服", "寶寶衣服"], minKg: 0.15, maxKg: 0.5, defaultKg: 0.3, unit: "件" },
  { name: "童鞋", keywords: ["童鞋", "兒童鞋", "小孩鞋", "寶寶鞋"], minKg: 0.3, maxKg: 0.8, defaultKg: 0.5, unit: "雙" },

  // ── 其他 ──
  { name: "地墊/地毯", keywords: ["地墊", "地毯", "腳踏墊"], minKg: 1, maxKg: 3, defaultKg: 2.0, unit: "塊" },
  { name: "鍋具", keywords: ["鍋", "鍋具", "炒鍋", "平底鍋", "湯鍋", "電鍋"], minKg: 1, maxKg: 3, defaultKg: 2.0, unit: "個" },
  { name: "書籍", keywords: ["書", "書籍", "小說", "漫畫"], minKg: 0.3, maxKg: 0.8, defaultKg: 0.5, unit: "本" },
];

// ========== 商品清單解析 ==========

export interface ParsedItem {
  /** 匹配到的商品 */
  product: ProductWeight;
  /** 數量 */
  quantity: number;
  /** 原始匹配文字 */
  matchedText: string;
  /** 單件估算重量 */
  unitWeight: number;
  /** 小計重量 */
  subtotalWeight: number;
}

export interface EstimationResult {
  /** 解析出的商品清單 */
  items: ParsedItem[];
  /** 總估算重量（kg） */
  totalWeight: number;
  /** 運費報價 */
  quote: ShippingQuote;
  /** 特殊提醒列表 */
  notes: string[];
}

// 中文數字映射
const CN_NUM_MAP: Record<string, number> = {
  '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
  '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
  '兩': 2, '壹': 1, '貳': 2, '參': 3, '肆': 4,
  '伍': 5, '陸': 6, '柒': 7, '捌': 8, '玖': 9, '拾': 10,
  '幾': 3, // 「幾件」預設當 3 件估算
};

/**
 * 解析中文或阿拉伯數字
 */
function parseQuantity(text: string): number {
  // 阿拉伯數字
  const numMatch = text.match(/(\d+)/);
  if (numMatch) return parseInt(numMatch[1], 10);

  // 中文數字
  for (const [cn, num] of Object.entries(CN_NUM_MAP)) {
    if (text.includes(cn)) return num;
  }

  return 1; // 預設 1
}

/**
 * 從自然語言文字中解析商品清單
 * 
 * 支援格式：
 * - 「3件T恤」「一雙鞋」「2盒面膜」
 * - 「3件T恤和一雙鞋」「2件衛衣+1個背包」
 * - 「買了3件T恤、一雙鞋、2盒面膜」
 * - 「想寄5件衣服和2盒面膜」
 */
export function parseProductList(text: string): ParsedItem[] {
  const lower = text.toLowerCase();
  const items: ParsedItem[] = [];
  const matchedPositions = new Set<number>(); // 避免同一位置重複匹配

  // 對每個商品品類嘗試匹配
  for (const product of PRODUCT_WEIGHT_DB) {
    for (const keyword of product.keywords) {
      const kwLower = keyword.toLowerCase();
      const idx = lower.indexOf(kwLower);
      if (idx === -1) continue;

      // 避免同一位置被多個品類匹配（優先匹配更長的關鍵詞）
      if (matchedPositions.has(idx)) continue;

      // 嘗試在關鍵詞前方找數量
      // 模式：(數字)(量詞)?(商品名) 或 (中文數字)(量詞)?(商品名)
      const beforeText = text.substring(Math.max(0, idx - 10), idx);
      
      // 嘗試匹配 「3件」「一雙」「2個」「5盒」 等
      const qtyMatch = beforeText.match(
        /(\d+|[一二三四五六七八九十兩幾])\s*(?:件|雙|個|組|盒|條|頂|把|副|塊|本|瓶|套|對)?\s*$/
      );

      let quantity = 1;
      if (qtyMatch) {
        quantity = parseQuantity(qtyMatch[1]);
      } else {
        // 也嘗試在關鍵詞後方找數量（如「T恤3件」）
        const afterText = text.substring(idx + keyword.length, idx + keyword.length + 10);
        const afterMatch = afterText.match(
          /^\s*(\d+|[一二三四五六七八九十兩幾])\s*(?:件|雙|個|組|盒|條|頂|把|副|塊|本|瓶|套|對)?/
        );
        if (afterMatch) {
          quantity = parseQuantity(afterMatch[1]);
        }
      }

      // 限制合理數量範圍
      quantity = Math.min(Math.max(quantity, 1), 50);

      const unitWeight = product.defaultKg;
      const subtotalWeight = Math.round(unitWeight * quantity * 100) / 100;

      items.push({
        product,
        quantity,
        matchedText: keyword,
        unitWeight,
        subtotalWeight,
      });

      // 標記此位置已匹配
      for (let i = idx; i < idx + keyword.length; i++) {
        matchedPositions.add(i);
      }

      break; // 同一品類只匹配一次（第一個匹配的關鍵詞）
    }
  }

  // 去重：如果同一個通用品類和具體品類都匹配了，移除通用的
  // 例如：「衣服（通用）」和「T恤」同時匹配，移除「衣服（通用）」
  const specificNames = items.map(i => i.product.name);
  const filtered = items.filter(item => {
    if (item.product.name.includes("（通用）")) {
      // 檢查是否有同類的具體品類
      const category = item.product.name.replace("（通用）", "");
      const hasSpecific = items.some(other => 
        other !== item && 
        !other.product.name.includes("（通用）") &&
        PRODUCT_WEIGHT_DB.some(p => 
          p.name === other.product.name && 
          p.keywords.some(k => item.product.keywords.some(ik => k.includes(ik) || ik.includes(k)))
        )
      );
      // 如果有更具體的衣服類/鞋子類匹配，移除通用的
      if (category === "衣服" && items.some(o => o !== item && ["T恤/上衣", "襯衫", "帽T/衛衣", "牛仔褲", "褲子", "洋裝/裙子", "外套/夾克", "羽絨外套/大衣", "運動套裝", "睡衣", "內衣/內褲"].includes(o.product.name))) {
        return false;
      }
      if (category === "鞋子" && items.some(o => o !== item && ["運動鞋/球鞋", "涼鞋/拖鞋", "靴子", "皮鞋"].includes(o.product.name))) {
        return false;
      }
    }
    return true;
  });

  return filtered;
}

// ========== 估算觸發偵測 ==========

const ESTIMATE_TRIGGERS = [
  '幫我估', '估一下', '估算', '幫估', '估個',
  '大概多少', '大約多少', '大概要多少',
  '幫我算', '算一下', '算看看',
];

const PURCHASE_VERBS = [
  '買了', '想買', '要買', '買',
  '想寄', '要寄', '寄',
  '想運', '要運',
  '下單', '訂了', '訂購',
];

/**
 * 偵測是否為商品估算請求
 * 
 * 條件（滿足其一）：
 * 1. 包含估算觸發詞 + 至少一個商品品類
 * 2. 包含購物動詞 + 至少一個商品品類 + 數量
 * 3. 包含 2 個以上商品品類（暗示清單）
 */
export function isProductEstimateTrigger(text: string): boolean {
  const lower = text.toLowerCase();

  // 先檢查是否有商品品類匹配
  const items = parseProductList(text);
  if (items.length === 0) return false;

  // 條件 1：估算觸發詞 + 商品
  if (ESTIMATE_TRIGGERS.some(t => lower.includes(t))) {
    return true;
  }

  // 條件 2：購物動詞 + 商品 + 數量
  if (PURCHASE_VERBS.some(v => lower.includes(v)) && items.some(i => i.quantity > 0)) {
    return true;
  }

  // 條件 3：2 個以上商品品類（暗示是清單）
  if (items.length >= 2) {
    return true;
  }

  return false;
}

// ========== 估算計算 ==========

/**
 * 執行商品清單估算（含運費計算）
 */
export async function estimateProductList(text: string): Promise<EstimationResult | null> {
  const items = parseProductList(text);
  if (items.length === 0) return null;

  const totalWeight = Math.round(items.reduce((sum, item) => sum + item.subtotalWeight, 0) * 100) / 100;

  if (totalWeight <= 0) return null;

  // 收集特殊提醒
  const notes: string[] = [];
  const noteSet = new Set<string>();
  for (const item of items) {
    if (item.product.note && !noteSet.has(item.product.note)) {
      noteSet.add(item.product.note);
      notes.push(item.product.note);
    }
  }

  // 計算運費
  const quote = await calculateShippingWithRate(totalWeight);

  return {
    items,
    totalWeight,
    quote,
    notes,
  };
}

// ========== LINE 訊息格式化 ==========

/** 強調金額 */
function bold(text: string): string {
  return `【${text}】`;
}

/**
 * 將估算結果格式化為 LINE 訊息
 */
export function formatEstimationMessage(result: EstimationResult): string {
  const { items, totalWeight, quote, notes } = result;
  const rival = quote.rival;

  const lines: string[] = [];

  // 標題
  lines.push(`🛒 商品重量估算結果`);
  lines.push(``);

  // 逐項列出
  lines.push(`📋 商品明細：`);
  for (const item of items) {
    const qtyStr = item.quantity > 1 ? `${item.quantity}${item.product.unit}` : `1${item.product.unit}`;
    lines.push(`   • ${item.product.name} × ${qtyStr} ≈ ${item.subtotalWeight}kg`);
    lines.push(`     （每${item.product.unit} ${item.product.minKg}-${item.product.maxKg}kg，估 ${item.unitWeight}kg）`);
  }

  lines.push(``);
  lines.push(`📦 預估總重量：${bold(`${totalWeight} kg`)}`);

  // 特殊提醒
  if (notes.length > 0) {
    lines.push(``);
    for (const note of notes) {
      lines.push(`${note}`);
    }
  }

  lines.push(``);

  // ── 運費計算 ──
  const air = quote.airExpress;
  const sea = quote.seaExpress;
  const del = quote.delivery;

  lines.push(`━━━━━━━━━━━━━━━━`);
  lines.push(``);

  // 空快
  lines.push(`✈️ 極速空快（${air.deliveryDays}到台）`);
  lines.push(`   倉老闆：${bold(`${air.totalRMB} RMB ≈ NT$${air.totalTWD}`)}`);
  if (rival.airSavedTWD > 0) {
    lines.push(`   🔥 比市場行情省 ${bold(`NT$${rival.airSavedTWD}`)}`);
  } else if (rival.airSavedTWD < 0) {
    lines.push(`   ✅ 全程包稅 + 免費驗貨 + 1-2天到台`);
  }

  lines.push(``);

  // 海快
  lines.push(`🚢 新航線海快（${sea.deliveryDays}到台）`);
  lines.push(`   倉老闆：${bold(`${sea.totalRMB} RMB ≈ NT$${sea.totalTWD}`)}`);
  if (rival.seaSavedTWD > 0) {
    lines.push(`   🔥 比市場行情省 ${bold(`NT$${rival.seaSavedTWD}`)}`);
  } else if (rival.seaSavedTWD < 0) {
    lines.push(`   ✅ 全程包稅 + 免費驗貨 + 3-5天到台`);
  }

  lines.push(``);

  // 派送費
  lines.push(`🚚 台灣派送費（另計）：`);
  lines.push(`   • 郵局 i 郵箱：${del.iPost}`);
  lines.push(`   • 順豐宅配：NT$${del.sfExpress}`);

  lines.push(``);

  // 總結
  if (rival.airSavedTWD > 0 || rival.seaSavedTWD > 0) {
    const bestSaving = Math.max(rival.airSavedTWD, rival.seaSavedTWD);
    const bestChannel = rival.seaSavedTWD >= rival.airSavedTWD ? '海快' : '空快';
    lines.push(`💰 選倉老闆${bestChannel}最多可省 ${bold(`NT$${bestSaving}`)}！`);
  }
  lines.push(`✅ 全程包稅，不記拋，免費驗貨`);

  lines.push(``);

  // 匯率
  const rateLabel = quote.isLiveRate
    ? `📊 匯率：1 RMB ≈ ${quote.exchangeRate} TWD（台灣銀行即時匯率）`
    : `📊 匯率：1 RMB ≈ ${quote.exchangeRate} TWD（參考匯率）`;
  lines.push(rateLabel);

  lines.push(``);
  // ── 合併出貨省錢提示（重量 < 2kg）──
  if (totalWeight < 2) {
    lines.push(``);
    lines.push(`💡 省錢小技巧：`);
    lines.push(`   預估總重僅 ${totalWeight}kg，台灣派送費佔比較高。`);
    lines.push(`   建議多件商品合併寄送，派送費只收一次！`);
    lines.push(`   例如湊到 3-5kg 一起寄，每公斤運費不變，`);
    lines.push(`   但派送費均攤下來更划算 🎯`);
  }
  lines.push(``);
  lines.push(`⚠️ 以上為估算值，實際重量以到倉秤重為準`);
  lines.push(`💡 想調整商品？直接告訴我新的清單！`);
  lines.push(`📱 精確試算：https://cangpro.com/#calculator`);

  return lines.join('\n');
}
