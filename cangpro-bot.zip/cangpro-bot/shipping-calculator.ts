/**
 * 運費試算器
 * 
 * 根據用戶輸入的重量計算空快和海快的運費，
 * 整合台灣銀行即時匯率，同時顯示 RMB 和 TWD 金額，
 * 加入同行對比（與官網運費試算器一致），
 * 並格式化為 LINE 訊息回覆。
 * 
 * 費率：
 * - 極速空快：21 RMB/kg（1-2 天到台）
 * - 新航線海快：14 RMB/kg（3-5 天到台）
 * - 全程包稅，不記拋
 * 
 * 競品費率（市場行情）：
 * - 空運：首重 29 RMB/1kg，續重 15.5 RMB/0.5kg，不足 0.5kg 進位，時效 2-4 天
 * - 海快：NT$70/kg，不滿 10kg 以 10kg 計，時效 7-14 天
 * 
 * 台灣派送費：
 * - 郵局 i 郵箱：NT$55-70
 * - 順豐宅配：NT$95-245（依重量分級）
 */

import { fetchCNYRate } from "../routers/exchange";

// ========== 小包規格上限 ==========

/** 單件重量上限（kg） */
export const MAX_SINGLE_WEIGHT = 20;

/** 單邊尺寸上限（cm） */
export const MAX_SINGLE_DIMENSION = 100;

/** 三邊總和上限（cm） */
export const MAX_TOTAL_DIMENSIONS = 150;

// ========== 費率常數 ==========

/** 空快費率（RMB/kg） */
export const AIR_EXPRESS_RATE = 21;

/** 海快費率（RMB/kg） */
export const SEA_EXPRESS_RATE = 14;

/** 順豐宅配費率表（重量上限 kg → 費用 NTD） */
export const SF_DELIVERY_RATES: { maxKg: number; fee: number }[] = [
  { maxKg: 1, fee: 95 },
  { maxKg: 5, fee: 115 },
  { maxKg: 10, fee: 165 },
  { maxKg: 15, fee: 205 },
  { maxKg: 20, fee: 245 },
];

/** 郵局 i 郵箱費率（NTD） */
export const IPOST_FEE_MIN = 55;
export const IPOST_FEE_MAX = 70;

/** 備用匯率（當台灣銀行 API 無法連線時使用，基於現金賣出匯率） */
export const FALLBACK_RATE = 4.684;

// ========== 競品費率常數 ==========

/** 市場行情空運：首重 29 RMB（1kg 內） */
export const RIVAL_AIR_FIRST = 29;

/** 市場行情空運：續重每 0.5kg 收 15.5 RMB */
export const RIVAL_AIR_CONT = 15.5;

/** 市場行情海快：NT$70/kg */
export const RIVAL_SEA_RATE_NTD = 70;

/** 市場行情海快：不滿 10kg 以 10kg 計 */
export const RIVAL_SEA_MIN_KG = 10;

// ========== 重量提取 ==========

/**
 * 從用戶訊息中提取重量（kg）
 * 
 * 支援格式：
 * - 純數字：「1.66」「3」「0.5」
 * - 帶單位：「1.66kg」「3KG」「5公斤」「500g」「500克」
 * - 帶空格：「1.66 kg」「3 公斤」
 * 
 * @returns 重量（kg），或 null 表示無法識別
 */
export function extractWeight(text: string): number | null {
  const trimmed = text.trim();

  const match = trimmed.match(
    /^(\d+\.?\d*)\s*(kg|KG|Kg|kG|公斤|斤|g|克|G)?$/i
  );

  if (!match) return null;

  const value = parseFloat(match[1]);
  const unit = (match[2] || '').toLowerCase();

  if (isNaN(value) || value <= 0) return null;

  if (unit === 'g' || unit === '克') {
    const kg = value / 1000;
    if (kg < 0.01 || kg > 500) return null;
    return kg;
  }

  if (value < 0.01 || value > 500) return null;
  return value;
}

// ========== 匯率查詢 ==========

/**
 * 取得 CNY/TWD 匯率（含 fallback）
 */
export async function getCNYRate(): Promise<{ rate: number; isLive: boolean }> {
  try {
    const rate = await fetchCNYRate();
    return { rate, isLive: true };
  } catch (err) {
    console.error("[ShippingCalc] 匯率抓取失敗，使用備用值:", err);
    return { rate: FALLBACK_RATE, isLive: false };
  }
}

// ========== 競品費用計算 ==========

export interface RivalComparison {
  airRivalRMB: number;       // 競品空運頭程 RMB
  airRivalTWD: number;       // 競品空運頭程 TWD
  seaRivalTWD: number;       // 競品海快 TWD（直接以 NTD 計算）
  airSavedTWD: number;       // 空快省多少 TWD（正=我們便宜，負=我們貴）
  seaSavedTWD: number;       // 海快省多少 TWD
  airRivalLabel: string;     // 競品空運費率說明
  seaRivalLabel: string;     // 競品海快費率說明
}

/**
 * 計算競品費用（與官網邏輯完全一致）
 */
export function calculateRivalCost(
  weightKg: number,
  exchangeRate: number,
  ourAirTWD: number,
  ourSeaTWD: number,
): RivalComparison {
  // 空運：首重 29 RMB/1kg，超出部分每 0.5kg 收 15.5 RMB，不足 0.5kg 進位
  let airRivalRMB: number;
  if (weightKg <= 1) {
    airRivalRMB = RIVAL_AIR_FIRST;
  } else {
    const extraKg = weightKg - 1;
    const extraUnits = Math.ceil(extraKg / 0.5);
    airRivalRMB = RIVAL_AIR_FIRST + extraUnits * RIVAL_AIR_CONT;
  }
  const airRivalTWD = Math.round(airRivalRMB * exchangeRate);

  // 海快：NT$70/kg，不滿 10kg 以 10kg 計
  const billedKg = Math.max(RIVAL_SEA_MIN_KG, weightKg);
  const seaRivalTWD = Math.round(billedKg * RIVAL_SEA_RATE_NTD);

  return {
    airRivalRMB,
    airRivalTWD,
    seaRivalTWD,
    airSavedTWD: airRivalTWD - ourAirTWD,
    seaSavedTWD: seaRivalTWD - ourSeaTWD,
    airRivalLabel: `市場行情空運（首重 29 RMB，續重 15.5 RMB/0.5kg）`,
    seaRivalLabel: `市場行情海快（NT$70/kg，不滿 10kg 以 10kg 計）`,
  };
}

// ========== 運費計算 ==========

export interface ShippingQuote {
  weight: number;
  airExpress: {
    ratePerKg: number;
    totalRMB: number;
    totalTWD: number;
    deliveryDays: string;
  };
  seaExpress: {
    ratePerKg: number;
    totalRMB: number;
    totalTWD: number;
    deliveryDays: string;
  };
  delivery: {
    iPost: string;
    sfExpress: number;
  };
  rival: RivalComparison;
  exchangeRate: number;
  isLiveRate: boolean;
}

/**
 * 計算運費報價（同步版）
 */
export function calculateShipping(
  weightKg: number,
  exchangeRate: number = FALLBACK_RATE,
  isLiveRate: boolean = false,
): ShippingQuote {
  const airTotal = Math.round(weightKg * AIR_EXPRESS_RATE * 100) / 100;
  const seaTotal = Math.round(weightKg * SEA_EXPRESS_RATE * 100) / 100;

  const airTWD = Math.round(airTotal * exchangeRate);
  const seaTWD = Math.round(seaTotal * exchangeRate);

  let sfFee = SF_DELIVERY_RATES[SF_DELIVERY_RATES.length - 1].fee;
  for (const tier of SF_DELIVERY_RATES) {
    if (weightKg <= tier.maxKg) {
      sfFee = tier.fee;
      break;
    }
  }

  const rival = calculateRivalCost(weightKg, exchangeRate, airTWD, seaTWD);

  return {
    weight: weightKg,
    airExpress: {
      ratePerKg: AIR_EXPRESS_RATE,
      totalRMB: airTotal,
      totalTWD: airTWD,
      deliveryDays: '1-2 天',
    },
    seaExpress: {
      ratePerKg: SEA_EXPRESS_RATE,
      totalRMB: seaTotal,
      totalTWD: seaTWD,
      deliveryDays: '3-5 天',
    },
    delivery: {
      iPost: `NT$${IPOST_FEE_MIN}-${IPOST_FEE_MAX}`,
      sfExpress: sfFee,
    },
    rival,
    exchangeRate,
    isLiveRate,
  };
}

/**
 * 計算運費報價（非同步版，含即時匯率）
 */
export async function calculateShippingWithRate(weightKg: number): Promise<ShippingQuote> {
  const { rate, isLive } = await getCNYRate();
  return calculateShipping(weightKg, rate, isLive);
}

// ========== 小包規格檢查 ==========

/**
 * 檢查商品是否超過小包規格限制
 * 
 * @param weightKg 重量（kg）
 * @param maxDimension 單邊尺寸（cm），可選
 * @param totalDimensions 三邊總和（cm），可選
 * @returns 是否超過限制
 */
export function exceedsPackageLimit(
  weightKg: number,
  maxDimension?: number,
  totalDimensions?: number
): boolean {
  // 檢查重量
  if (weightKg > MAX_SINGLE_WEIGHT) return true;

  // 檢查單邊尺寸
  if (maxDimension !== undefined && maxDimension > MAX_SINGLE_DIMENSION) return true;

  // 檢查三邊總和
  if (totalDimensions !== undefined && totalDimensions > MAX_TOTAL_DIMENSIONS) return true;

  return false;
}

/**
 * 生成超過限制的警告訊息
 */
export function generatePackageLimitWarning(
  weightKg: number,
  maxDimension?: number,
  totalDimensions?: number
): string {
  const warnings: string[] = [];

  if (weightKg > MAX_SINGLE_WEIGHT) {
    warnings.push(`⚠️ 重量超限：${weightKg}kg > ${MAX_SINGLE_WEIGHT}kg 上限`);
  }

  if (maxDimension !== undefined && maxDimension > MAX_SINGLE_DIMENSION) {
    warnings.push(`⚠️ 單邊超限：${maxDimension}cm > ${MAX_SINGLE_DIMENSION}cm 上限`);
  }

  if (totalDimensions !== undefined && totalDimensions > MAX_TOTAL_DIMENSIONS) {
    warnings.push(`⚠️ 三邊總和超限：${totalDimensions}cm > ${MAX_TOTAL_DIMENSIONS}cm 上限`);
  }

  const lines: string[] = [];
  lines.push(`🚫 哎呀，這件有點太大了！`);
  lines.push(``);
  lines.push(`倉老闆的小包快線有以下規格限制：`);
  lines.push(`   • 單件重量：不超過 ${MAX_SINGLE_WEIGHT}kg`);
  lines.push(`   • 單邊尺寸：不超過 ${MAX_SINGLE_DIMENSION}cm`);
  lines.push(`   • 三邊總和：不超過 ${MAX_TOTAL_DIMENSIONS}cm`);
  lines.push(``);
  lines.push(`您的商品情況：`);
  for (const warning of warnings) {
    lines.push(`   ${warning}`);
  }
  lines.push(``);
  lines.push(`💡 建議方案：`);
  lines.push(`   1️⃣ 拆成兩包或多包寄送（每包都在限制內）`);
  lines.push(`   2️⃣ 找大件物流服務（例如家具、大型機台）`);
  lines.push(`   3️⃣ 聯絡我們討論特殊方案`);
  lines.push(``);
  lines.push(`📞 有問題？歡迎詢問客服：`);
  lines.push(`   LINE：https://line.me/R/ti/p/@clb888`);
  lines.push(``);
  lines.push(`倉老闆專注於電商小包，確保快速、安全、有品質的服務！`);

  return lines.join('\n');
}

// ========== LINE 文字強調工具 ==========

/**
 * LINE 不支援 Markdown 粗體，使用 Unicode 全形括號和特殊符號來強調
 * 
 * 策略：
 * - 金額用【】框起來
 * - 重要結論用 ⟫⟫ 箭頭標記
 * - 省錢金額用 🔥 強調
 */

/** 強調金額 */
function bold(text: string): string {
  return `【${text}】`;
}

// ========== LINE 訊息格式化 ==========

/**
 * 將運費報價格式化為 LINE 訊息（含雙幣、同行對比、文字強調）
 */
export function formatShippingQuoteMessage(quote: ShippingQuote): string {
  const w = quote.weight;
  const air = quote.airExpress;
  const sea = quote.seaExpress;
  const del = quote.delivery;
  const rival = quote.rival;

  // 匯率來源標示
  const rateLabel = quote.isLiveRate
    ? `📊 匯率：1 RMB ≈ ${quote.exchangeRate} TWD（台灣銀行現金賣出匯率）`
    : `📊 匯率：1 RMB ≈ ${quote.exchangeRate} TWD（參考匯率）`;

  const lines: string[] = [];

  lines.push(`📦 ${bold(`${w} kg`)} 運費試算結果`);
  lines.push(``);

  // ── 空快 ──
  lines.push(`✈️ 極速空快（${air.deliveryDays}到台）`);
  lines.push(`   倉老闆：${bold(`${air.totalRMB} RMB ≈ NT$${air.totalTWD}`)}`);
  lines.push(`   （${air.ratePerKg} RMB/kg × ${w} kg）`);

  // 空快同行對比
  if (rival.airSavedTWD > 0) {
    // 我們比較便宜
    lines.push(`   🔥 比市場行情省 ${bold(`NT$${rival.airSavedTWD}`)}`);
    lines.push(`   ⟫ 市場行情：${rival.airRivalRMB} RMB ≈ NT$${rival.airRivalTWD}`);
  } else if (rival.airSavedTWD === 0) {
    lines.push(`   📊 與市場行情持平`);
  } else {
    // 我們比較貴 — 參考官網：強調全程包稅、免費驗貨、時效更快
    lines.push(`   ✅ 全程包稅 + 免費驗貨 + 1-2天到台`);
    lines.push(`   ⟫ 市場行情：${rival.airRivalRMB} RMB ≈ NT$${rival.airRivalTWD}（2-4天，不含驗貨）`);
  }

  lines.push(``);

  // ── 海快 ──
  lines.push(`🚢 新航線海快（${sea.deliveryDays}到台）`);
  lines.push(`   倉老闆：${bold(`${sea.totalRMB} RMB ≈ NT$${sea.totalTWD}`)}`);
  lines.push(`   （${sea.ratePerKg} RMB/kg × ${w} kg）`);

  // 海快同行對比
  if (rival.seaSavedTWD > 0) {
    lines.push(`   🔥 比市場行情省 ${bold(`NT$${rival.seaSavedTWD}`)}`);
    lines.push(`   ⟫ 市場行情：NT$${rival.seaRivalTWD}（NT$70/kg，不滿10kg以10kg計）`);
  } else if (rival.seaSavedTWD === 0) {
    lines.push(`   📊 與市場行情持平`);
  } else {
    lines.push(`   ✅ 全程包稅 + 免費驗貨 + 3-5天到台`);
    lines.push(`   ⟫ 市場行情：NT$${rival.seaRivalTWD}（7-14天，不含驗貨）`);
  }

  lines.push(``);

  // ── 台灣派送費 ──
  lines.push(`🚚 台灣派送費（另計）：`);
  lines.push(`   • 郵局 i 郵箱：${del.iPost}`);
  lines.push(`   • 順豐宅配：NT$${del.sfExpress}`);

  lines.push(``);

  // ── 總結：根據對比結果決定文案 ──
  // 至少有一個渠道比較便宜就強調省錢
  if (rival.airSavedTWD > 0 || rival.seaSavedTWD > 0) {
    const bestSaving = Math.max(rival.airSavedTWD, rival.seaSavedTWD);
    const bestChannel = rival.seaSavedTWD >= rival.airSavedTWD ? '海快' : '空快';
    lines.push(`💰 選倉老闆${bestChannel}最多可省 ${bold(`NT$${bestSaving}`)}！`);
  }

  lines.push(`✅ 全程包稅，不記拋，免費驗貨，沒有隱藏費用`);

  lines.push(``);
  lines.push(rateLabel);
  lines.push(``);
  // ── 合併出貨省錢提示（重量 < 2kg）──
  if (w < 2) {
    lines.push(``);
    lines.push(`💡 省錢小技巧：`);
    lines.push(`   您的包裹僅 ${w}kg，台灣派送費佔比較高。`);
    lines.push(`   建議多件商品合併寄送，派送費只收一次！`);
    lines.push(`   例如湊到 3-5kg 一起寄，每公斤運費不變，`);
    lines.push(`   但派送費均攤下來更划算 🎯`);
  }

  lines.push(``);
  lines.push(`💡 想換個重量試算？直接輸入數字即可`);
  lines.push(`📱 更詳細的試算：https://cangpro.com/#calculator`);

  return lines.join('\n');
}

// ========== 觸發詞偵測 ==========

const SHIPPING_CALC_TRIGGERS = [
  '試算', '算運費', '運費試算', '計算運費', '算一下',
  '幫我算', '幫算', '估算', '估價',
  '我要算', '想算', '算看看',
  '幫我估', '幫我計算',
  '怎麼算', '多少錢', '運費多少', '費用多少',
  '算費用', '查運費', '運費查詢',
];

/**
 * 偵測用戶訊息是否為運費試算請求
 */
export function isShippingCalcTrigger(text: string): boolean {
  const lower = text.toLowerCase().trim();

  // 觸發詞匹配
  if (SHIPPING_CALC_TRIGGERS.some(t => lower.includes(t))) {
    return true;
  }

  // 數字+單位 ... 運費相關詞（中間可以有任意字）
  // 例如：「5公斤的貨怎麼算」「3kg運費多少」
  if (/\d+\.?\d*\s*(kg|公斤|斤|克|g).{0,10}(多少|運費|費用|怎麼算|算|計算|試算|價格)/i.test(lower)) {
    return true;
  }

  // 運費相關詞 ... 數字+單位
  // 例如：「運費多少5kg」
  if (/(多少|運費|費用|怎麼算|算|計算|試算|價格).{0,10}\d+\.?\d*\s*(kg|公斤|斤|克|g)/i.test(lower)) {
    return true;
  }

  // 「重量」+數字 的模式（如「重量5公斤」）
  if (/重量.{0,5}\d+\.?\d*\s*(kg|公斤|斤|克|g)?/i.test(lower)) {
    return true;
  }

  // 包含數字+單位且包含「寄」「運」「費」「算」等關鍵字
  if (/\d+\.?\d*\s*(kg|公斤|斤)/i.test(lower) && /(寄|運|費|算|價|多少)/i.test(lower)) {
    return true;
  }

  return false;
}

/**
 * 從運費試算請求中提取重量
 */
export function extractWeightFromQuery(text: string): number | null {
  const trimmed = text.trim();

  // 先嘗試匹配帶單位的重量（如 3kg、5公斤、500g）
  const match = trimmed.match(
    /(\d+\.?\d*)\s*(kg|KG|Kg|公斤|斤|g|克|G)/i
  );

  if (match) {
    const value = parseFloat(match[1]);
    const unit = (match[2] || '').toLowerCase();

    if (isNaN(value) || value <= 0) return null;

    if (unit === 'g' || unit === '克') {
      const kg = value / 1000;
      return (kg >= 0.01 && kg <= 500) ? kg : null;
    }

    return (value >= 0.01 && value <= 500) ? value : null;
  }

  // 沒有單位，但是觸發詞匹配了，嘗試提取數字作為重量（kg）
  if (isShippingCalcTrigger(trimmed)) {
    const numMatch = trimmed.match(/(\d+\.?\d*)/);
    if (numMatch) {
      const value = parseFloat(numMatch[1]);
      if (!isNaN(value) && value >= 0.01 && value <= 500) {
        return value;
      }
    }
  }

  return null;
}

/**
 * 生成「請輸入重量」的提示訊息
 */
export function generateWeightPrompt(): string {
  return [
    '📦 運費試算器',
    '',
    '請輸入您的商品重量（公斤），例如：',
    '• 輸入「1.5」代表 1.5 公斤',
    '• 輸入「3kg」代表 3 公斤',
    '• 輸入「500g」代表 500 克',
    '',
    '💡 我會立即幫您計算空快和海快的運費，還會跟市場行情做對比！',
    '',
    '📏 倉老闆小包限制：',
    `   • 單件重量不超過 ${MAX_SINGLE_WEIGHT}kg`,
    `   • 單邊尺寸不超過 ${MAX_SINGLE_DIMENSION}cm`,
    `   • 三邊總和不超過 ${MAX_TOTAL_DIMENSIONS}cm`,
  ].join('\n');
}

/**
 * 檢查用戶最近的對話歷史是否包含運費相關話題
 */
export function hasRecentShippingContext(
  history: { role: 'user' | 'assistant'; content: string }[]
): boolean {
  const recent = history.slice(-4);

  const shippingKeywords = [
    '運費', '試算', '多少錢', '費用', '價格', '公斤', 'kg',
    '空快', '海快', '重量', '算', '計算', '估算',
    '運費試算', '運費計算', '頭程', 'RMB/kg',
  ];

  for (const msg of recent) {
    const lower = msg.content.toLowerCase();
    if (shippingKeywords.some(kw => lower.includes(kw))) {
      return true;
    }
  }

  return false;
}

// ========== 尺寸提取 ==========

/**
 * 從用戶訊息中提取尺寸信息
 * 
 * 支援格式：
 * - 單邊：「50cm」「100cm」
 * - 三邊：「50×40×30」「50*40*30」「50 40 30」
 * 
 * @returns { maxDimension?: number; totalDimensions?: number }
 */
export function extractDimensions(
  text: string
): { maxDimension?: number; totalDimensions?: number } {
  const trimmed = text.trim();
  const result: { maxDimension?: number; totalDimensions?: number } = {};

  // 嘗試匹配三邊尺寸（×、*、空格分隔）
  const threeDimMatch = trimmed.match(
    /(\d+)\s*[×*x]\s*(\d+)\s*[×*x]\s*(\d+)/i
  );
  if (threeDimMatch) {
    const d1 = parseInt(threeDimMatch[1]);
    const d2 = parseInt(threeDimMatch[2]);
    const d3 = parseInt(threeDimMatch[3]);
    result.maxDimension = Math.max(d1, d2, d3);
    result.totalDimensions = d1 + d2 + d3;
    return result;
  }

  // 嘗試匹配單邊尺寸
  const singleDimMatch = trimmed.match(/(\d+)\s*cm/i);
  if (singleDimMatch) {
    result.maxDimension = parseInt(singleDimMatch[1]);
    return result;
  }

  return result;
}


